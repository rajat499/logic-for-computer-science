Put the argument in `arg.sml` file as specified in the file

* Run using: `sml driver.sml`