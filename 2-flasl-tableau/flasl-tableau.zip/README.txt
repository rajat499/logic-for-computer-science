The lexer and parser is my own implementation from Assignment 1.

* Build using: `make`
* Run using: `sml proptableau.sml arg-inp.flasl`